package com.tweetapp.entity;

public class TweetTest {
}
