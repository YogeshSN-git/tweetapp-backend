package com.tweetapp.entity;

public class UserTest {
}
