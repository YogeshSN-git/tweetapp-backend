package com.tweetapp.controller;

import com.tweetapp.entity.Reply;
import com.tweetapp.entity.Tweet;
import com.tweetapp.entity.User;
import com.tweetapp.service.TweetService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

public class TwitterControllerTest {

    @InjectMocks
    TweetController tweetController;

    @Mock
    TweetService tweetService;

    List<Tweet> tweetList=new ArrayList<>();



}
