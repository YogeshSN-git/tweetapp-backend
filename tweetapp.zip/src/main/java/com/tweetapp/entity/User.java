package com.tweetapp.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name="userEntity")
public class User {

    @Id
    @Column(name = "username", columnDefinition = "varchar(255)")
    private String username;
    private String name;
    private String password;
    @OneToMany(mappedBy="user")
    private List<Tweet> tweetList;
}
