package com.tweetapp.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name="tweet")
public class Tweet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int tweetId;
    private String tweet;
    @OneToMany(mappedBy="tweet")
    private List<Reply> replyList;
    @ManyToOne
    @JoinColumn(name="username")
    @JsonIgnore
    private User user;
    private int likes;

    public Tweet(User user, String tweet) {
        this.user=user;
        this.tweet=tweet;
    }
}
