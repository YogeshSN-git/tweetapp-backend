package com.tweetapp.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name="reply")
public class Reply {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int replyId;
    private String reply;
    @ManyToOne
    @JoinColumn(name="username")
    @JsonIgnore
    private User user;
    @ManyToOne
    @JoinColumn(name="tweetId")
    @JsonIgnore
    private Tweet tweet;


    public Reply(String reply, User user) {
        this.reply=reply;
        this.user=user;
    }
}
