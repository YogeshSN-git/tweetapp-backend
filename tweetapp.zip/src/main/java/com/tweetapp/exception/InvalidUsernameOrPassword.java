package com.tweetapp.exception;

public class InvalidUsernameOrPassword extends Exception {

    public InvalidUsernameOrPassword() {
        super("Invalid Username Or Password... Try again");
    }
}
