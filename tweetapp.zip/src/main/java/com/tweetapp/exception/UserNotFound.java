package com.tweetapp.exception;

import java.util.function.Supplier;

public class UserNotFound extends Exception {

    public UserNotFound() {
        super("User Not Found... Try again");
    }
}
