package com.tweetapp.exception;

public class UsernameAlreadyPresent extends Throwable {

    public UsernameAlreadyPresent() {
        super("Username Already Present... Try different username");
    }
}
