package com.tweetapp.feign;

public class AuthFeign {
}
