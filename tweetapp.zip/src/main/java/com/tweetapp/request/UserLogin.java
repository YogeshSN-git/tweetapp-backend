package com.tweetapp.request;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class UserLogin {

    private String username;
    private String password;
}
