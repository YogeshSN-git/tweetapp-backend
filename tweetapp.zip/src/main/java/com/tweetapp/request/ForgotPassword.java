package com.tweetapp.request;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class ForgotPassword {

    private String userName;
    @Getter
    @Setter
    private String password;
    private String confirmPassword;
}
