package com.tweetapp.controller;

import com.tweetapp.service.TweetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.tweetapp.entity.Tweet;
import com.tweetapp.exception.UserNotFound;

import java.util.List;

@RestController
public class TweetController {

    @Autowired
    TweetService tweetService;

    @GetMapping("/all")
    public List<Tweet> getAllTweets(){
        return tweetService.getAllTweets();
    }

    @GetMapping("/{username}")
    public List<Tweet> getUserTweets(@PathVariable String username) throws UserNotFound {
        return tweetService.getUserTweets(username);
    }

    @PostMapping("/{username}/add")
    public void addTweet(@PathVariable String username, @RequestBody String tweet) throws UserNotFound {
        tweetService.addTweet(username, tweet);
    }

    @PutMapping("/{username}/update/{id}")
    public void updateTweet(@PathVariable String username, @RequestBody String tweet,@PathVariable int id) throws UserNotFound {
        tweetService.updateTweet(username, tweet,id);
    }

    @DeleteMapping("/{username}/delete/{id}")
    public void deleteTweet(@PathVariable String username, @PathVariable int id) throws UserNotFound {
        tweetService.deleteTweet(username, id);
    }

    @PutMapping("/{username}/like/{id}")
    public void likeTweet(@PathVariable String username,@PathVariable int id) throws UserNotFound {
        tweetService.likeTweet(username, id);
    }

//    @PostMapping("/{username}/reply/{id}")
//    public void replyTweet(@PathVariable String username, @RequestBody String reply,@PathVariable int id) throws UserNotFound {
//        tweetService.replyTweet(username, id,reply);
//    }

}
