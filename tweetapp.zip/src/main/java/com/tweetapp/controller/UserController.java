package com.tweetapp.controller;

import com.tweetapp.entity.User;
import com.tweetapp.exception.InvalidUsernameOrPassword;
import com.tweetapp.exception.UsernameAlreadyPresent;
import com.tweetapp.request.ForgotPassword;
import com.tweetapp.request.UserLogin;
import com.tweetapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.tweetapp.exception.UserNotFound;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("/register")
    public String register(@RequestBody User user) throws UsernameAlreadyPresent {
        System.out.println(user.toString());
        userService.registerUser(user);
        return "User registered Successfully";
    }

    @GetMapping("/login")
    public User login(@RequestBody UserLogin userLogin) throws UserNotFound, InvalidUsernameOrPassword {
        return userService.validateUserCredentials(userLogin);
    }

    @GetMapping("/{username}/forgot")
    public String forgotPassword(@PathVariable String username, @RequestBody ForgotPassword password) throws UserNotFound {
        userService.updatePassword(username,password);
        return "Password updated for "+username;
    }

    @GetMapping("/users/all")
    public List<User> getAllUsers(){
        return userService.getAllUsers();
    }

    @GetMapping("/user/search/{username}")
    public List<User> searchUsername(@PathVariable String username) throws UserNotFound {
        return userService.searchUser(username);
    }
}
