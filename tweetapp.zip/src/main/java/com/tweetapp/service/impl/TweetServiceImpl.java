package com.tweetapp.service.impl;

import com.tweetapp.entity.Reply;

import com.tweetapp.entity.User;
import com.tweetapp.service.TweetService;
import com.tweetapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.entity.Tweet;
import com.tweetapp.exception.UserNotFound;
import com.tweetapp.repository.TweetRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class TweetServiceImpl implements TweetService {

    @Autowired
    TweetRepository tweetRepository;

    @Autowired
    UserService userService;

    @Override
    public List<Tweet> getAllTweets() {
        return tweetRepository.findAll();
    }

    @Override
    public void addTweet(String username, String tweet) throws UserNotFound {
        User user=userService.getUser(username);
        Tweet newTweet=new Tweet(user,tweet);
        tweetRepository.save(newTweet);
    }

    @Override
    public Tweet getTweet(int tweetId) {
        return tweetRepository.findById(tweetId).get();
    }

    @Override
    public List<Tweet> getUserTweets(String username) throws UserNotFound {
        User user=userService.getUser(username);
        return user.getTweetList();
    }

    @Override
    public void updateTweet(String username, String tweetContent, int tweetId) {
        Tweet tweet=tweetRepository.findById(tweetId).get();
        tweet.setTweet(tweetContent);
        tweetRepository.save(tweet);
    }

    @Override
    public void deleteTweet(String username, int tweetId) throws UserNotFound {
        Tweet tweet=tweetRepository.findById(tweetId).get();
        tweetRepository.delete(tweet);
        User user=userService.getUser(username);
        user.getTweetList().remove(tweet);
        userService.updateUser(user);
    }

    @Override
    public void likeTweet(String username, int tweetId) {
        Tweet tweet=tweetRepository.findById(tweetId).get();
        tweet.setLikes(tweet.getLikes()+1);
        tweetRepository.save(tweet);
    }

    @Override
    public void replyTweet(String username, int tweetId, String reply) throws UserNotFound {
        Tweet tweet=tweetRepository.findById(tweetId).get();

        User user=userService.getUser(username);
        List<Reply> replyList;
        if(tweet.getReplyList()==null){
            replyList=new ArrayList<>();
        }else{
            replyList=tweet.getReplyList();
        }
        replyList.add(new Reply(reply,user));
        tweet.setReplyList(replyList);
        tweetRepository.save(tweet);
    }
}
