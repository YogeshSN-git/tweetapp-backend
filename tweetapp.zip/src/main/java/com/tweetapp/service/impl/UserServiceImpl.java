package com.tweetapp.service.impl;

import com.tweetapp.entity.User;
import com.tweetapp.exception.UsernameAlreadyPresent;
import com.tweetapp.repository.UserRepository;
import com.tweetapp.request.ForgotPassword;
import com.tweetapp.request.UserLogin;
import com.tweetapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.exception.InvalidUsernameOrPassword;
import com.tweetapp.exception.UserNotFound;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepository userRepository;

    public User registerUser(User user) throws UsernameAlreadyPresent {
        if(userRepository.findById(user.getUsername()).isPresent()){
            throw new UsernameAlreadyPresent();
        }

        return userRepository.save(user);
    }

    @Override
    public User validateUserCredentials(UserLogin userLogin) throws UserNotFound, InvalidUsernameOrPassword {
        User user=getUser(userLogin.getUsername());
        if(!user.getPassword().equals(userLogin.getPassword())){
            throw new InvalidUsernameOrPassword();
        }
        return user;
    }

    @Override
    public void updatePassword(String username, ForgotPassword forgotPassword) throws UserNotFound {
       if(!forgotPassword.getPassword().equals(forgotPassword.getConfirmPassword())){

       }
        User user =getUser(username);
       user.setPassword(forgotPassword.getPassword());
       userRepository.save(user);
    }

    @Override
    public User getUser(String username) throws UserNotFound {
        Optional<User> user=userRepository.findById(username);
        if(!user.isPresent()){
            throw new UserNotFound();
        }
        return user.get();
    }

    @Override
    public List<User> searchUser(String username) throws UserNotFound {
        List<User> user=userRepository.findByUsernameContainingIgnoreCase(username);
        if(user.isEmpty()){
            throw new UserNotFound();
        }
        return user;
    }

    @Override
    public List<User> getAllUsers(){
        return userRepository.findAll();
    }

    @Override
    public void updateUser(User user) {
        userRepository.save(user);
    }
}
