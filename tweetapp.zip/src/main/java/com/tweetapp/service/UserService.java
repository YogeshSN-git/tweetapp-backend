package com.tweetapp.service;

import com.tweetapp.entity.User;
import com.tweetapp.exception.UsernameAlreadyPresent;
import com.tweetapp.request.ForgotPassword;
import com.tweetapp.request.UserLogin;
import com.tweetapp.exception.InvalidUsernameOrPassword;
import com.tweetapp.exception.UserNotFound;

import java.util.List;

public interface UserService {
    public User validateUserCredentials(UserLogin userLogin) throws UserNotFound, InvalidUsernameOrPassword;
    public User registerUser(User user) throws UsernameAlreadyPresent;
    public void updatePassword(String username, ForgotPassword forgotPassword) throws UserNotFound;
    public User getUser(String username) throws UserNotFound;
    public List<User> searchUser(String username) throws UserNotFound;
    public List<User> getAllUsers();

    void updateUser(User user);
}
