package com.tweetapp.service;

import com.tweetapp.entity.Tweet;
import com.tweetapp.exception.UserNotFound;
import java.util.List;

public interface TweetService {
    public List<Tweet> getAllTweets();
    public void addTweet(String username,String tweet) throws UserNotFound;
    public Tweet getTweet(int tweetId);
    public List<Tweet> getUserTweets(String username) throws UserNotFound;
    public void updateTweet(String username,String tweet,int tweetId);
    public void deleteTweet(String username,int tweetId) throws UserNotFound;
    public void likeTweet(String username,int tweetId);
    public void replyTweet(String username,int tweetId,String reply) throws UserNotFound;
}
